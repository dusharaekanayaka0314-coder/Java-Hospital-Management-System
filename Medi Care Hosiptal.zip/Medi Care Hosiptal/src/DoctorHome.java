import javax.swing.table.DefaultTableModel;

import javax.swing.JOptionPane;



public class DoctorHome extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DoctorHome.class.getName());

    /**
     * Creates new form DoctorHome
     */
    public DoctorHome() {
        initComponents();
        setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnFindPatient = new javax.swing.JButton();
        btnAddTreatment = new javax.swing.JButton();
        btnViewAppointment = new javax.swing.JButton();
        btnLogout = new javax.swing.JButton();
        btnViewTestReports = new javax.swing.JButton();
        btnViewPatientCareRecords = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1370770, 1370770));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        btnFindPatient.setBackground(new java.awt.Color(0, 153, 153));
        btnFindPatient.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnFindPatient.setText("Search Patient");
        btnFindPatient.addActionListener(this::btnFindPatientActionPerformed);

        btnAddTreatment.setBackground(new java.awt.Color(0, 153, 153));
        btnAddTreatment.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnAddTreatment.setText("Add Medical Record");
        btnAddTreatment.addActionListener(this::btnAddTreatmentActionPerformed);

        btnViewAppointment.setBackground(new java.awt.Color(0, 153, 153));
        btnViewAppointment.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnViewAppointment.setText("View Appointments");
        btnViewAppointment.addActionListener(this::btnViewAppointmentActionPerformed);

        btnLogout.setBackground(new java.awt.Color(0, 153, 153));
        btnLogout.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnLogout.setText("Logout");
        btnLogout.addActionListener(this::btnLogoutActionPerformed);

        btnViewTestReports.setBackground(new java.awt.Color(0, 153, 153));
        btnViewTestReports.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnViewTestReports.setText("View Test Reports");
        btnViewTestReports.addActionListener(this::btnViewTestReportsActionPerformed);

        btnViewPatientCareRecords.setBackground(new java.awt.Color(0, 153, 153));
        btnViewPatientCareRecords.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        btnViewPatientCareRecords.setText("View Patient Care Records");
        btnViewPatientCareRecords.addActionListener(this::btnViewPatientCareRecordsActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnViewPatientCareRecords)
                    .addComponent(btnLogout)
                    .addComponent(btnFindPatient)
                    .addComponent(btnAddTreatment)
                    .addComponent(btnViewTestReports)
                    .addComponent(btnViewAppointment))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFindPatient)
                .addGap(19, 19, 19)
                .addComponent(btnViewTestReports)
                .addGap(18, 18, 18)
                .addComponent(btnViewAppointment)
                .addGap(18, 18, 18)
                .addComponent(btnAddTreatment)
                .addGap(18, 18, 18)
                .addComponent(btnViewPatientCareRecords)
                .addGap(18, 18, 18)
                .addComponent(btnLogout)
                .addContainerGap(47, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, -1, 360));

        jLabel2.setFont(new java.awt.Font("Bodoni MT Black", 0, 48)); // NOI18N
        jLabel2.setText("Doctor Dashboard");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 160, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/medicare.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFindPatientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindPatientActionPerformed
    new FindPatientUI().setVisible(true);
    this.dispose(); 
    }//GEN-LAST:event_btnFindPatientActionPerformed

    private void btnAddTreatmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddTreatmentActionPerformed
    new MedicalRecordUI().setVisible(true);
    this.dispose();
    }//GEN-LAST:event_btnAddTreatmentActionPerformed

    private void btnViewAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewAppointmentActionPerformed
       new ViewAppointmentUI().setVisible(true);
    }//GEN-LAST:event_btnViewAppointmentActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int b =JOptionPane.showConfirmDialog(null,"Do you want to close application?","select",JOptionPane.YES_NO_OPTION);
        if(b==0){
            setVisible(false);
            new MainUI().setVisible(true);
        }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnViewPatientCareRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewPatientCareRecordsActionPerformed
        new DoctorPatientCareViewUI().setVisible(true);
        this.dispose();

    }//GEN-LAST:event_btnViewPatientCareRecordsActionPerformed

    private void btnViewTestReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewTestReportsActionPerformed
     new DoctorTestReportViewUI().setVisible(true);
     this.dispose();
    }//GEN-LAST:event_btnViewTestReportsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
   
        java.awt.EventQueue.invokeLater(() -> {
                new DoctorHome().setVisible(true);
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddTreatment;
    private javax.swing.JButton btnFindPatient;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnViewAppointment;
    private javax.swing.JButton btnViewPatientCareRecords;
    private javax.swing.JButton btnViewTestReports;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
