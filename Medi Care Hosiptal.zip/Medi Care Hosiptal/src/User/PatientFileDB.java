package User;
import java.util.ArrayList;
import Business.Patient;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;



public class PatientFileDB {

    private static final String FILE_NAME = "patient.txt";

    
    public boolean add(Patient p) {
        
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true));

            bw.write(
                p.getPersonID() + "," +
                p.getFirstName() + "," +
                p.getLastName() + "," +
                p.getDateOfBirth() + "," +
                p.getGender() + "," +
                p.getContactNumber() + "," +
                p.getEmail() + "," +
                p.getAddress()
            );

            bw.newLine();
            bw.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace(); 
            return false;
        }
    }

    
    public ArrayList<Patient> getAll() {

        ArrayList<Patient> plist = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;

            while ((line = br.readLine()) != null) {

                String[] d = line.split(",");

                Patient p = new Patient();
                p.setPersonID(Integer.parseInt(d[0]));
                p.setFirstName(d[1]);
                p.setLastName(d[2]);
                p.setDateOfBirth(java.sql.Date.valueOf(d[3]));
                p.setGender(d[4]);
                p.setContactNumber(d[5]);
                p.setEmail(d[6]);
                p.setAddress(d[7]);

                plist.add(p);
            }

            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return plist;
    }

   
    public Patient find(int id) {

        ArrayList<Patient> list = getAll();
        

        for (Patient p : list) {
            if (p.getPersonID() == id) {
                return p;
            }
        }
        return null;
    }

    
    public boolean delete(int id) {

        ArrayList<Patient> list = getAll();

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME));

            for (Patient p : list) {
                if (p.getPersonID() != id) {

                    bw.write(
                        p.getPersonID() + "," +
                        p.getFirstName() + "," +
                        p.getLastName() + "," +
                        p.getDateOfBirth() + "," +
                        p.getGender() + "," +
                        p.getContactNumber() + "," +
                        p.getEmail() + "," +
                        p.getAddress()
                    );
                    bw.newLine();
                }
            }

            bw.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
  
public boolean update(Patient pNew) {

    ArrayList<Patient> list = getAll();
    boolean updated = false;

    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME));

        for (Patient p : list) {

           
            if (p.getPersonID() == pNew.getPersonID()) {
                p = pNew;
                updated = true;
            }

            bw.write(
                p.getPersonID() + "," +
                p.getFirstName() + "," +
                p.getLastName() + "," +
                p.getDateOfBirth() + "," +
                p.getGender() + "," +
                p.getContactNumber() + "," +
                p.getEmail() + "," +
                p.getAddress()
            );
            bw.newLine();
        }

        bw.close();
        return updated;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}

}
