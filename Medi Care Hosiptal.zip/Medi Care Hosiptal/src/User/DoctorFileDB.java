package User;

import Business.Doctor;
import java.io.*;
import java.util.ArrayList;

public class DoctorFileDB {

    private static final String FILE_NAME = "Doctor.txt";


    public boolean add(Doctor d) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true));

            bw.write(
                d.getPersonID() + "," +
                d.getFirstName() + "," +
                d.getLastName() + "," +
                d.getSpecialization() + "," +
                d.getLicenseNumber() + "," +
                d.getConsultationFee() + "," +
                d.getYearsOfExperience() + "," +
                d.getDepartment() + "," +
                d.getContactNumber() + "," +
                d.getEmail()
            );
            bw.newLine();
            bw.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public ArrayList<Doctor> getAll() {

        ArrayList<Doctor> list = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;

            while ((line = br.readLine()) != null) {

                String[] d = line.split(",");

                Doctor doc = new Doctor();

                doc.setPersonID(Integer.parseInt(d[0]));
                doc.setFirstName(d[1]);
                doc.setLastName(d[2]);
                doc.setSpecialization(d[3]);
                doc.setLicenseNumber(d[4]);
                doc.setConsultationFee(Double.parseDouble(d[5]));
                doc.setYearsOfExperience(d[6]);
                doc.setDepartment(d[7]);
                doc.setContactNumber(d[8]);
                doc.setEmail(d[9]);

                list.add(doc);
            }

            br.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
