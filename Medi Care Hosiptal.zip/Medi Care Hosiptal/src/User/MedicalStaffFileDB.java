package User;

import Business.MedicalStaff;
import java.io.*;
import java.sql.Date;
import java.util.ArrayList;

public class MedicalStaffFileDB {

    private static final String FILE_NAME = "medicalstaff.txt";

 
    public boolean add(MedicalStaff s) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true))) {

            bw.write(
                s.getStaffID() + "," +
                s.getPersonID() + "," +
                s.getFirstName() + "," +
                s.getLastName() + "," +
                s.getDepartment() + "," +
                s.getHireDate() + "," +
                s.getSalary() + "," +
                s.getWorkSchedule() + "," +
                s.getQualifications() + "," +
                s.getStaffType() + "," +
                s.getGender() + "," +
                s.getContactNumber() + "," +
                s.getEmail() + "," +
                s.getAddress()
            );
            bw.newLine();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    
    public ArrayList<MedicalStaff> getAll() {
        ArrayList<MedicalStaff> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                MedicalStaff s = new MedicalStaff() {
                    @Override
                    public boolean login(String u, String p) { return false; }

                    @Override
                    public void updateSchedule(String newSchedule) {
                        setWorkSchedule(newSchedule);
                    }

                    @Override
                    public String getWorkingHours() {
                        return getWorkSchedule();
                    }

                    @Override
                    public void performDuties() {}
                };

                s.setStaffID(Integer.parseInt(d[0]));
                s.setPersonID(Integer.parseInt(d[1]));
                s.setFirstName(d[2]);
                s.setLastName(d[3]);
                s.setDepartment(d[4]);
                s.setHireDate(Date.valueOf(d[5]));
                s.setSalary(Double.parseDouble(d[6]));
                s.setWorkSchedule(d[7]);
                s.setQualifications(d[8]);
                s.setStaffType(d[9]);
                s.setGender(d[10]);
                s.setContactNumber(d[11]);
                s.setEmail(d[12]);
                s.setAddress(d[13]);

                list.add(s);
            }

        } catch (FileNotFoundException e) {
           
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

   
    public MedicalStaff find(int staffID) {
        for (MedicalStaff s : getAll()) {
            if (s.getStaffID() == staffID) {
                return s;
            }
        }
        return null;
    }

   
    public boolean delete(int staffID) {
        ArrayList<MedicalStaff> list = getAll();
        boolean deleted = false;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {

            for (MedicalStaff s : list) {
                if (s.getStaffID() != staffID) {
                    bw.write(
                        s.getStaffID() + "," +
                        s.getPersonID() + "," +
                        s.getFirstName() + "," +
                        s.getLastName() + "," +
                        s.getDepartment() + "," +
                        s.getHireDate() + "," +
                        s.getSalary() + "," +
                        s.getWorkSchedule() + "," +
                        s.getQualifications() + "," +
                        s.getStaffType() + "," +
                        s.getGender() + "," +
                        s.getContactNumber() + "," +
                        s.getEmail() + "," +
                        s.getAddress()
                    );
                    bw.newLine();
                } else {
                    deleted = true;
                }
            }
            return deleted;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

   
    public boolean update(MedicalStaff newStaff) {
        ArrayList<MedicalStaff> list = getAll();
        boolean updated = false;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {

            for (MedicalStaff s : list) {
                if (s.getStaffID() == newStaff.getStaffID()) {
                    s = newStaff;
                    updated = true;
                }

                bw.write(
                    s.getStaffID() + "," +
                    s.getPersonID() + "," +
                    s.getFirstName() + "," +
                    s.getLastName() + "," +
                    s.getDepartment() + "," +
                    s.getHireDate() + "," +
                    s.getSalary() + "," +
                    s.getWorkSchedule() + "," +
                    s.getQualifications() + "," +
                    s.getStaffType() + "," +
                    s.getGender() + "," +
                    s.getContactNumber() + "," +
                    s.getEmail() + "," +
                    s.getAddress()
                );
                bw.newLine();
            }
            return updated;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
