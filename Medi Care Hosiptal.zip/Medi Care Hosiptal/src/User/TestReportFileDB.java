package User;
import Business.TestReport;
import java.io.*;
import java.util.*;

public class TestReportFileDB {

    private final String FILE = "testreports.txt";

    public boolean add(TestReport r) {
        try (FileWriter fw = new FileWriter(FILE, true)) {
            fw.write(r.getReportID() + "," +
                     r.getPatientID() + "," +
                     r.getTestName() + "," +
                     r.getTestDate() + "," +
                     r.getResult() + "\n");
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public List<TestReport> getAll() {
        List<TestReport> list = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");
                TestReport r = new TestReport();
                r.setReportID(Integer.parseInt(d[0]));
                r.setPatientID(Integer.parseInt(d[1]));
                r.setTestName(d[2]);
                r.setTestDate(d[3]);
                r.setResult(d[4]);
                list.add(r);
            }
        } catch (Exception e) {}
        return list;
    }
}
