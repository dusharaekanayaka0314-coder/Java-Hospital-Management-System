
package User;
import java.util.ArrayList;
import Business.Patient;
import Business.Person;


public class PersonDB {
    private ArrayList<Patient> PatientList;
    
    public PersonDB(){
        PatientList = new ArrayList<>();
        
    }
    public boolean add(Patient p){
    PatientList.add(p);
    return true;
    }
    public ArrayList<Patient>getAll(){
        return PatientList;
        
    }
    
}
