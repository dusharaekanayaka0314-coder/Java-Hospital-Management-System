package User;

import Business.Appointment;
import java.io.*;
import java.util.ArrayList;
import Business.Patient;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.FileReader;

public class AppointmentFileDB {

    private static final String FILE_NAME = "appointment.txt";


    public boolean add(Appointment a) {

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true));

            bw.write(
                a.getAppointmentID() + "," +
                a.getPatientID() + "," +
                a.getDoctor() + "," +
                a.getDate() + "," +
                a.getTime() + "," +
                a.getStatus()+ ","+
                a.getNote()
            );

            bw.newLine();
            bw.close();
            return true;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    public Appointment find(int appID) {
    ArrayList<Appointment> list = getAll();
    for (Appointment a : list) {
        if (a.getAppointmentID() == appID) {
            return a;
        }
    }
    return null;
}
public boolean delete(int appID) {
    ArrayList<Appointment> list = getAll();
    boolean deleted = false;

    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME));
        for (Appointment a : list) {
            if (a.getAppointmentID() != appID) {
                bw.write(
                    a.getAppointmentID() + "," +
                    a.getPatientID() + "," +
                    a.getDoctor() + "," +
                    a.getDate() + "," +
                    a.getTime() + "," +
                    a.getStatus() + "," +
                    a.getNote()
                );
                bw.newLine();
            } else {
                deleted = true;
            }
        }
        bw.close();
        return deleted;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
public boolean update(Appointment aNew) {
    ArrayList<Appointment> list = getAll();
    boolean updated = false;

    try {
        BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME));
        for (Appointment a : list) {
            if (a.getAppointmentID() == aNew.getAppointmentID()) {
                a = aNew;
                updated = true;
            }
            bw.write(
                a.getAppointmentID() + "," +
                a.getPatientID() + "," +
                a.getDoctor() + "," +
                a.getDate() + "," +
                a.getTime() + "," +
                a.getStatus() + "," +
                a.getNote()
            );
            bw.newLine();
        }
        bw.close();
        return updated;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}




   
    public ArrayList<Appointment> getAll() {

        ArrayList<Appointment> list = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(FILE_NAME));
            String line;

            while ((line = br.readLine()) != null) {

                String[] d = line.split(",");

                Appointment a = new Appointment();
                a.setAppointmentID(Integer.parseInt(d[0]));
                a.setPatientID(Integer.parseInt(d[1]));
                a.setDoctor(d[2]);
                a.setDate(java.sql.Date.valueOf(d[3]));
                a.setTime(d[4]);
                a.setStatus(d[5]);
                a.setNote(d[6]);

                list.add(a);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
