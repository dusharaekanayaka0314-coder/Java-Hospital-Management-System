package User;

import Business.MedicalRecord;
import java.io.*;
import java.util.ArrayList;
import java.sql.Date;

public class MedicalRecordFileDB {

    private static final String FILE_NAME = "medicalrecord.txt";


    public boolean add(MedicalRecord m) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            bw.write(
                m.getRecordID() + "," +
                m.getPatientID() + "," +
                m.getDoctor() + "," +
                m.getVisitDate() + "," +
                m.getSymptoms() + "," +
                m.getDiagnosis() + "," +
                m.getTreatment() + "," +
                m.getPrescription() + "," +
                m.getTestResults()
            );
            bw.newLine();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public ArrayList<MedicalRecord> getAll() {
        ArrayList<MedicalRecord> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;

            while ((line = br.readLine()) != null) {
                String[] d = line.split(",");

                MedicalRecord m = new MedicalRecord();
                m.setRecordID(Integer.parseInt(d[0]));
                m.setPatientID(Integer.parseInt(d[1]));
                m.setDoctor(d[2]);
                m.setVisitDate(Date.valueOf(d[3]));
                m.setSymptoms(d[4]);
                m.setDiagnosis(d[5]);
                m.setTreatment(d[6]);
                m.setPrescription(d[7]);
                m.setTestResults(d[8]);

                list.add(m);
            }
        } catch (FileNotFoundException e) {
           
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }


    public MedicalRecord find(int recordID) {
        for (MedicalRecord m : getAll()) {
            if (m.getRecordID() == recordID) {
                return m;
            }
        }
        return null;
    }


    public boolean delete(int recordID) {
        ArrayList<MedicalRecord> list = getAll();
        boolean deleted = false;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (MedicalRecord m : list) {
                if (m.getRecordID() != recordID) {
                    bw.write(
                        m.getRecordID() + "," +
                        m.getPatientID() + "," +
                        m.getDoctor() + "," +
                        m.getVisitDate() + "," +
                        m.getSymptoms() + "," +
                        m.getDiagnosis() + "," +
                        m.getTreatment() + "," +
                        m.getPrescription() + "," +
                        m.getTestResults()
                    );
                    bw.newLine();
                } else {
                    deleted = true;
                }
            }
            return deleted;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean update(MedicalRecord mNew) {
        ArrayList<MedicalRecord> list = getAll();
        boolean updated = false;

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (MedicalRecord m : list) {
                if (m.getRecordID() == mNew.getRecordID()) {
                    m = mNew;
                    updated = true;
                }
                bw.write(
                    m.getRecordID() + "," +
                    m.getPatientID() + "," +
                    m.getDoctor() + "," +
                    m.getVisitDate() + "," +
                    m.getSymptoms() + "," +
                    m.getDiagnosis() + "," +
                    m.getTreatment() + "," +
                    m.getPrescription() + "," +
                    m.getTestResults()
                );
                bw.newLine();
            }
            return updated;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
