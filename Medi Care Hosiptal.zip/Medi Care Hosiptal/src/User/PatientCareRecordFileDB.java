package User;

import Business.PatientCareRecord;
import java.io.*;
import java.util.*;

public class PatientCareRecordFileDB {

    private final String FILE_NAME = "patientcarerecords.txt";

    public boolean add(PatientCareRecord r) {
        try (FileWriter fw = new FileWriter(FILE_NAME, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write(
                r.getCareID() + "," +
                r.getPatientID() + "," +
                r.getNurseName() + "," +
                r.getCareDate() + "," +
                r.getNotes()
            );
            bw.newLine();
            return true;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ArrayList<PatientCareRecord> getAll() {
        ArrayList<PatientCareRecord> list = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",",5);

                PatientCareRecord r = new PatientCareRecord();
                r.setCareID(Integer.parseInt(data[0]));
                r.setPatientID(Integer.parseInt(data[1]));
                r.setNurseName(data[2]);
                r.setCareDate(data[3]);
                r.setNotes(data[4]);

                list.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
