
package User;

import java.util.ArrayList;
import Business.Person;

public interface IData {
    public abstract boolean add(Person p);
    public abstract Person find(int pID);
    public abstract boolean delete(int pID);
    public abstract boolean update(Person p);
    public abstract ArrayList<Person> getAll();
}
