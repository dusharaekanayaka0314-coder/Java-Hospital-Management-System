import Business.Appointment;
import java.util.Date;
import User.AppointmentFileDB;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.util.ArrayList;


public class AppointmentUI extends javax.swing.JFrame {
    
    private AppointmentFileDB aDB;
    private DefaultTableModel tblModelApp;
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AppointmentUI.class.getName()); 
        
public AppointmentUI() {
    initComponents();
    setLocationRelativeTo(null);

    aDB = new AppointmentFileDB();

    tblModelApp = new DefaultTableModel();
    tblModelApp.addColumn("App.ID");
    tblModelApp.addColumn("Patient ID");
    tblModelApp.addColumn("Doctor");
    tblModelApp.addColumn("Date");
    tblModelApp.addColumn("Time");
    tblModelApp.addColumn("Status");
    tblModelApp.addColumn("Notes");

    jTable1.setModel(tblModelApp);

    loadAppointmentsToTable(); 
}


private boolean checkVal() {

    if (txtPatientID.getText().equals("")){ //if text fields empty
        JOptionPane.showMessageDialog(this, "Patient ID cannot be blank");
        return false;
    }

    if (txtAppID.getText().equals("")) {
        JOptionPane.showMessageDialog(this, "Appointment ID cannot be blank");
        return false;
    }

    if (txtDate.getText().equals("")) {
        JOptionPane.showMessageDialog(this, "Appointment Date cannot be blank");
        return false;
    }

    if (txtTime.getText().equals("")) {
        JOptionPane.showMessageDialog(this, "Appointment Time cannot be blank");
        return false;
    }
        if (jComboBox1.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(this, "Select Appointment Status");
        return false;
    }

    if (txtNotes.getText().equals("")) {
        JOptionPane.showMessageDialog(this, "Notes cannot be blank");
        return false;
    }

    return true; 
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        lblAppID = new javax.swing.JLabel();
        lblPersonID = new javax.swing.JLabel();
        lblDoctorName = new javax.swing.JLabel();
        lblAppDate = new javax.swing.JLabel();
        lblAppTime = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtPatientID = new javax.swing.JTextField();
        txtAppID = new javax.swing.JTextField();
        comboDoctors = new javax.swing.JComboBox<>();
        txtDate = new javax.swing.JTextField();
        txtTime = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        txtNotes = new javax.swing.JTextField();
        btnSave = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        tblAppoinments = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        btnAppHistory = new javax.swing.JButton();
        btnFind = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1366, 770));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Britannic Bold", 0, 30)); // NOI18N
        jLabel1.setText("Schedule Appointment Form");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 150, -1, -1));

        lblAppID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblAppID.setText("Appoinment ID");
        getContentPane().add(lblAppID, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, -1, -1));

        lblPersonID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblPersonID.setText("Patient ID");
        getContentPane().add(lblPersonID, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, -1, -1));

        lblDoctorName.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblDoctorName.setText("Doctor");
        getContentPane().add(lblDoctorName, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, -1, -1));

        lblAppDate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblAppDate.setText("Appointment Date");
        getContentPane().add(lblAppDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, -1, -1));

        lblAppTime.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblAppTime.setText("Appointment Time");
        getContentPane().add(lblAppTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 390, -1, -1));

        lblStatus.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblStatus.setText("Status");
        getContentPane().add(lblStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 430, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("Notes");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, -1, -1));

        txtPatientID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        txtPatientID.setSelectionColor(new java.awt.Color(255, 255, 255));
        txtPatientID.addActionListener(this::txtPatientIDActionPerformed);
        getContentPane().add(txtPatientID, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 260, 270, -1));

        txtAppID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(txtAppID, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 220, 270, -1));

        comboDoctors.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        comboDoctors.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dermatologist", "General Physician", "Cardiologist", "Ophthalmologist" }));
        comboDoctors.addActionListener(this::comboDoctorsActionPerformed);
        getContentPane().add(comboDoctors, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 300, -1, -1));

        txtDate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(txtDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 340, 270, -1));
        getContentPane().add(txtTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 390, 270, -1));

        jComboBox1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pending", "Scheduled", "Cancelled", " " }));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 430, -1, -1));

        txtNotes.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        getContentPane().add(txtNotes, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 470, 270, 80));

        btnSave.setBackground(new java.awt.Color(51, 204, 255));
        btnSave.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(this::btnSaveActionPerformed);
        getContentPane().add(btnSave, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 570, 180, -1));

        btnCancel.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(this::btnCancelActionPerformed);
        getContentPane().add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 570, 180, -1));

        jTable1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "", "", "", "", "", "", ""
            }
        ));
        tblAppoinments.setViewportView(jTable1);

        getContentPane().add(tblAppoinments, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 80, 590, 490));

        btnAppHistory.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnAppHistory.setText("History");
        btnAppHistory.addActionListener(this::btnAppHistoryActionPerformed);
        getContentPane().add(btnAppHistory, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 40, 100, -1));

        btnFind.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnFind.setText("Find");
        btnFind.addActionListener(this::btnFindActionPerformed);
        getContentPane().add(btnFind, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 40, 100, -1));

        btnUpdate.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.addActionListener(this::btnUpdateActionPerformed);
        getContentPane().add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 40, 100, -1));

        btnDelete.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(this::btnDeleteActionPerformed);
        getContentPane().add(btnDelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 40, 100, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/medicare.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboDoctorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboDoctorsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboDoctorsActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        if (!checkVal()) {
        return;
        }
        try { 
        Appointment a = new Appointment(); 
        a.setAppointmentID(Integer.parseInt(txtAppID.getText()));
        a.setPatientID(Integer.parseInt(txtPatientID.getText()));
        a.setDoctor(comboDoctors.getSelectedItem().toString());
        a.setDate(java.sql.Date.valueOf(txtDate.getText()));
        a.setTime(txtTime.getText());
        a.setStatus(jComboBox1.getSelectedItem().toString());
        a.setNote(txtNotes.getText());
        
        AppointmentFileDB db = new AppointmentFileDB();
        if (db.add(a)) {
        JOptionPane.showMessageDialog(this, "Appointment Saved Successfully");
            loadAppointmentsToTable();
        } else {
        JOptionPane.showMessageDialog(this, "Error Saving Appointment");
        }
        }catch (Exception e) {
            JOptionPane.showMessageDialog(this,e.toString());
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnSaveActionPerformed
  
    
    private void txtPatientIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPatientIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPatientIDActionPerformed

    private void btnAppHistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppHistoryActionPerformed
       ArrayList<Appointment> list = aDB.getAll();
    tblModelApp.setRowCount(0); // clear table

    for (Appointment a : list) {
        tblModelApp.addRow(new Object[]{
            a.getAppointmentID(),
            a.getPatientID(),
            a.getDoctor(),
            a.getDate(),
            a.getTime(),
            a.getStatus(),
            a.getNote()
        });
    }
    }//GEN-LAST:event_btnAppHistoryActionPerformed

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelActionPerformed
        int c = JOptionPane.showConfirmDialog(null,"Do you want to close application?","Select",JOptionPane.YES_NO_OPTION);
        if (c==0)
        new ReceptionHome().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnCancelActionPerformed

    private void btnFindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindActionPerformed
         int id = Integer.parseInt(
        JOptionPane.showInputDialog("Enter Appointment ID")
    );

    Appointment a = aDB.find(id);

    if (a != null) {
        txtAppID.setText(String.valueOf(a.getAppointmentID()));
        txtPatientID.setText(String.valueOf(a.getPatientID()));
        comboDoctors.setSelectedItem(a.getDoctor());
        txtDate.setText(String.valueOf(a.getDate()));
        txtTime.setText(a.getTime());
        jComboBox1.setSelectedItem(a.getStatus());
        txtNotes.setText(a.getNote());
    } else {
        JOptionPane.showMessageDialog(this, "Appointment not found");
    }
    }//GEN-LAST:event_btnFindActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int id = Integer.parseInt(
        JOptionPane.showInputDialog("Enter Appointment ID")
    );

    if (aDB.delete(id)) {
        JOptionPane.showMessageDialog(this, "Appointment Deleted");
         loadAppointmentsToTable();
    } else {
        JOptionPane.showMessageDialog(this, "Appointment Not Found");
    }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        if (!checkVal()) return;

    Appointment a = new Appointment();
    a.setAppointmentID(Integer.parseInt(txtAppID.getText()));
    a.setPatientID(Integer.parseInt(txtPatientID.getText()));
    a.setDoctor(comboDoctors.getSelectedItem().toString());
    a.setDate(java.sql.Date.valueOf(txtDate.getText()));
    a.setTime(txtTime.getText());
    a.setStatus(jComboBox1.getSelectedItem().toString());
    a.setNote(txtNotes.getText());

    if (aDB.update(a)) {
        JOptionPane.showMessageDialog(this, "Appointment Updated");
        loadAppointmentsToTable();
    } else {
        JOptionPane.showMessageDialog(this, "Update Failed");
    }
    }//GEN-LAST:event_btnUpdateActionPerformed
    private void loadAppointmentsToTable() {

    AppointmentFileDB db = new AppointmentFileDB();
    ArrayList<Appointment> list = db.getAll();

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // table clear

    for (Appointment a : list) {
        model.addRow(new Object[]{
            a.getAppointmentID(),
            a.getPatientID(),
            a.getDoctor(),
            a.getDate(),
            a.getTime(),
            a.getStatus(),
            a.getNote()
        });
    }
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> {
            new AppointmentUI().setVisible(true);
                });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAppHistory;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnFind;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> comboDoctors;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblAppDate;
    private javax.swing.JLabel lblAppID;
    private javax.swing.JLabel lblAppTime;
    private javax.swing.JLabel lblDoctorName;
    private javax.swing.JLabel lblPersonID;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JScrollPane tblAppoinments;
    private javax.swing.JTextField txtAppID;
    private javax.swing.JTextField txtDate;
    private javax.swing.JTextField txtNotes;
    private javax.swing.JTextField txtPatientID;
    private javax.swing.JTextField txtTime;
    // End of variables declaration//GEN-END:variables
}
