package Business;

public class ChargeItem {
    private String description;
    private double unitPrice;
    private int quantity;

    public ChargeItem(String description, double unitPrice, int quantity) {
        this.description = description;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    public double getTotal() {
        return unitPrice * quantity;
    }

    public String getDescription() { 
        return description; 
    }
    public double getUnitPrice() { 
        return unitPrice; 
    }
    public int getQuantity() { 
        return quantity; 
    }
}
