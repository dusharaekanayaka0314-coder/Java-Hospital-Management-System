
package Business;

import java.util.Date;


public class Administrator extends Person {
    
    private String accessLevel;
    private String adminType;

    public Administrator() {
    }

    public Administrator(String accessLevel, String adminType, int personID, String firstName, String lastName, Date dateOfBirth, String gender, String contactNumber, String email, String address) {
        super(personID, firstName, lastName, dateOfBirth, gender, contactNumber, email, address);
        this.accessLevel = accessLevel;
        this.adminType = adminType;
    }



    public String getAccessLevel() {
        return accessLevel;
    }

    public void setAccessLevel(String accessLevel) {
        this.accessLevel = accessLevel;
    }

    public String getAdminType() {
        return adminType;
    }

    public void setAdminType(String adminType) {
        this.adminType = adminType;
    }
    
    public void login(){
    }
    public void generateReport(){
    }
    public void anageRecords(){
    }
    public void processPayment(){
    }
    public void registerPatient(){
        
    }
    
}
