package Business;

public class PatientCareRecord {
    private int careID;
    private int patientID;
    private String nurseName;
    private String careDate;
    private String notes;

    public int getCareID() { 
        return careID; 
    }
    public void setCareID(int careID) { 
        this.careID = careID; 
    }

    public int getPatientID() { 
        return patientID; 
    }
    public void setPatientID(int patientID) { 
        this.patientID = patientID;
    }

    public String getNurseName() { 
        return nurseName; 
    }
    public void setNurseName(String nurseName) { 
        this.nurseName = nurseName; 
    }

    public String getCareDate() { 
        return careDate; 
    }
    public void setCareDate(String careDate) { 
        this.careDate = careDate; 
    }

    public String getNotes() {
        return notes; 
    }
    public void setNotes(String notes) { 
        this.notes = notes;
    }
}
