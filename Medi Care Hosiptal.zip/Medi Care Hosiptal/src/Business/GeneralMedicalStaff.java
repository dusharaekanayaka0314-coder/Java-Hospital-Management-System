package Business;

public class GeneralMedicalStaff extends MedicalStaff {

    @Override
    public boolean login(String username, String password) {
        return true; 
    }

    @Override
    public void updateSchedule(String newSchedule) {
        setWorkSchedule(newSchedule);
    }

    @Override
    public String getWorkingHours() {
        return getWorkSchedule();
    }

    @Override
    public void performDuties() {
       
    }
}
