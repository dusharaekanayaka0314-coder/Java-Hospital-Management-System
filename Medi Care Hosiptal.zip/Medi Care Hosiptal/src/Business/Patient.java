
package Business;
import java.util.Date;


public class Patient extends Person  {
    
       private Date registrationDate;     
       private String bloodGroup;
       private String allergies;
       private String insuranceInfo;

    public Patient() {
        super();
    }

    public Patient(Date registrationDate, String bloodGroup, String allergies, String insuranceInfo, int personID, String firstName, String lastName, Date dateOfBirth, String gender, String contactNumber, String email, String address) {
        super(personID, firstName, lastName, dateOfBirth, gender, contactNumber, email, address);
        this.registrationDate = registrationDate;
        this.bloodGroup = bloodGroup;
        this.allergies = allergies;
        this.insuranceInfo = insuranceInfo;
    }



    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getAllergies() {
        return allergies;
    }

    public void setAllergies(String allergies) {
        this.allergies = allergies;
    }

    public String getInsuranceInfo() {
        return insuranceInfo;
    }

    public void setInsuranceInfo(String insuranceInfo) {
        this.insuranceInfo = insuranceInfo;
    }
         
    public void registerPatient(){
        
    }
    public void updateMedicalInfo(){
        
    }
    public void getMedicalHistory(){
        
    }
}
