package Business;

import java.sql.Date;


public class MedicalRecord {

    private int recordID;
    private int patientID;
    private String doctor;
    private Date visitDate;

    private String symptoms;
    private String diagnosis;
    private String treatment;
    private String prescription;
    private String testResults;

 
    public int getRecordID() {
        return recordID;
    }

    public void setRecordID(int recordID) {
        this.recordID = recordID;
    }

    public int getPatientID() {
        return patientID;
    }

    public void setPatientID(int patientID) {
        this.patientID = patientID;
    }

    public String getDoctor() {
        return doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public Date getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(Date visitDate) {
        this.visitDate = visitDate;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public String getPrescription() {
        return prescription;
    }

    public void setPrescription(String prescription) {
        this.prescription = prescription;
    }

    public String getTestResults() {
        return testResults;
    }

    public void setTestResults(String testResults) {
        this.testResults = testResults;
    }



    public void createRecord() {
        
    }

    public void updateRecord() {
       
    }

    public void addDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public void addTestResults(String testResults) {
        this.testResults = testResults;
    }

    public String generateSummary() {
        return "Patient ID: " + patientID +
               "\nDoctor: " + doctor +
               "\nDate: " + visitDate +
               "\nDiagnosis: " + diagnosis +
               "\nTreatment: " + treatment;
    }
}
