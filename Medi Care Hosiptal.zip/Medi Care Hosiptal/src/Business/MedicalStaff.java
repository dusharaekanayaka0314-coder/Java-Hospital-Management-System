package Business;

import java.sql.Date;


public abstract class MedicalStaff extends Person {

    private int staffID;
    private String department;
    private Date hireDate;
    private double salary;
    private String workSchedule;
    private String qualifications;
    private String staffType;

    public MedicalStaff() {}

    public MedicalStaff(
            int staffID,
            String department,
            Date hireDate,
            double salary,
            String workSchedule,
            String qualifications,
            String staffType,
            int personID,
            String firstName,
            String lastName,
            Date dateOfBirth,
            String gender,
            String contactNumber,
            String email,
            String address
    ) {
        super(personID, firstName, lastName, dateOfBirth, gender, contactNumber, email, address);
        this.staffID = staffID;
        this.department = department;
        this.hireDate = hireDate;
        this.salary = salary;
        this.workSchedule = workSchedule;
        this.qualifications = qualifications;
        this.staffType = staffType;
    }

    
    public int getStaffID() { 
        return staffID; 
    }
    public void setStaffID(int staffID) { 
        this.staffID = staffID; 
    }

    public String getDepartment() { 
        return department; 
    }
    public void setDepartment(String department) { 
        this.department = department; 
    }

    public Date getHireDate() { 
        return hireDate; 
    }
    public void setHireDate(Date hireDate) { 
        this.hireDate = hireDate; 
    }

    public double getSalary() { 
        return salary; 
    }
    public void setSalary(double salary) { 
        this.salary = salary; 
    }

    public String getWorkSchedule() {
        return workSchedule; 
    }
    public void setWorkSchedule(String workSchedule) {
        this.workSchedule = workSchedule; 
    }

    public String getQualifications() { 
        return qualifications; 
    }
    public void setQualifications(String qualifications) { 
        this.qualifications = qualifications; 
    }

    public String getStaffType() { 
        return staffType; 
    }
    public void setStaffType(String staffType) { 
        this.staffType = staffType;
    }

  
    public abstract boolean login(String username, String password);
    public abstract void updateSchedule(String newSchedule);
    public abstract String getWorkingHours();
    public abstract void performDuties();
}
