package Business;

public class Doctor extends MedicalStaff {

    private String specialization;
    private double consultationFee;
    private String licenseNumber;
    private String yearsOfExperience;

    public Doctor() {
    }


    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public double getConsultationFee() {
        return consultationFee;
    }

    public void setConsultationFee(double consultationFee) {
        this.consultationFee = consultationFee;
    }

    public String getLicenseNumber() {
        return licenseNumber;
    }

    public void setLicenseNumber(String licenseNumber) {
        this.licenseNumber = licenseNumber;
    }

    public String getYearsOfExperience() {
        return yearsOfExperience;
    }

    public void setYearsOfExperience(String yearsOfExperience) {
        this.yearsOfExperience = yearsOfExperience;
    }

    @Override
    public boolean login(String username, String password) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void updateSchedule(String newSchedule) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    /**
     *
     * @return
     */
    @Override
    public String getWorkingHours() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public void performDuties() {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    public void diagnosePatient(){
    }
    public void prescribeMedication(){
    }
    public void scheduleAppointment(){
        
    }
    public void generatePrescription(){
        
    }
}
