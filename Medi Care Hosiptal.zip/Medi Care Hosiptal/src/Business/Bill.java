package Business;

import java.util.ArrayList;
import java.util.Date;

public class Bill {

    private int billID;
    private int patientID;
    private String patientName;

    private ArrayList<ChargeItem> items = new ArrayList<>();

    private double consultationFees;
    private double testCharges;
    private double insuranceCoverage; 
    private double totalAmount;

    private String paymentStatus;
    private Date dueDate;

    

    public void addService(ChargeItem item) {
        items.add(item);
    }

    public double calculateTotal() {
        double sum = consultationFees + testCharges;

        for (ChargeItem item : items) {
            sum += item.getTotal();
        }

        totalAmount = applyInsuranceDiscount(sum);
        return totalAmount;
    }

    public double applyInsuranceDiscount(double amount) {
        return amount - (amount * insuranceCoverage / 100);
    }

    public void processPayment() {
        paymentStatus = "PAID";
    }

    public void generateBill() {
        calculateTotal();
        paymentStatus = "PENDING";
    }

    public void addService(){
        
    }
}
